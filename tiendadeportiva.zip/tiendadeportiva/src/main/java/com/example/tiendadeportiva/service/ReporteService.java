package com.example.tiendadeportiva.service;

import com.example.tiendadeportiva.entity.Producto;
import com.example.tiendadeportiva.entity.Venta;
import com.example.tiendadeportiva.repository.DetalleVentaRepository;
import com.example.tiendadeportiva.repository.ProductoRepository;
import com.example.tiendadeportiva.repository.VentaRepository;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class ReporteService {

    private final VentaRepository ventaRepository;
    private final DetalleVentaRepository detalleVentaRepository;
    private final ProductoRepository productoRepository;

    public ReporteService(VentaRepository ventaRepository,
                          DetalleVentaRepository detalleVentaRepository,
                          ProductoRepository productoRepository) {
        this.ventaRepository = ventaRepository;
        this.detalleVentaRepository = detalleVentaRepository;
        this.productoRepository = productoRepository;
    }

    public List<Venta> getVentasPorFecha(LocalDateTime inicio, LocalDateTime fin) {
        return ventaRepository.findByFechaBetween(inicio, fin);
    }

    // DTO para producto y cantidad vendida
    public static class ProductoCantidad {
        private Long productoId;
        private int cantidad;

        public ProductoCantidad(Long productoId, int cantidad) {
            this.productoId = productoId;
            this.cantidad = cantidad;
        }

        public Long getProductoId() { return productoId; }
        public int getCantidad() { return cantidad; }
    }

    public List<ProductoCantidad> getProductosMasVendidos() {
        List<Object[]> resultados = detalleVentaRepository.findProductosMasVendidos();
        return resultados.stream()
                .map(obj -> new ProductoCantidad(
                        (Long) obj[0],
                        ((Number) obj[1]).intValue()
                ))
                .collect(Collectors.toList());
    }

    public List<Producto> getProductosStockBajo(int limite) {
        return productoRepository.findProductosStockBajo(limite);
    }
}
