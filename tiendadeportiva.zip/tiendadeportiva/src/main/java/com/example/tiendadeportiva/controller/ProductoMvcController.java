package com.example.tiendadeportiva.controller;

import com.example.tiendadeportiva.service.ProductoService;
import com.example.tiendadeportiva.entity.Producto;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@RequestMapping("/productos")
public class ProductoMvcController {

    private final ProductoService productoService;

    public ProductoMvcController(ProductoService productoService) {
        this.productoService = productoService;
    }

    // Mostrar todos los productos disponibles
    @GetMapping
    public String listarProductos(Model model) {
        List<Producto> productos = productoService.listarProductosDisponibles();
        model.addAttribute("productos", productos);
        return "productos/lista"; // Vista Thymeleaf: productos/lista.html
    }

    // Filtrar productos por categoría o precio (opcional)
    @GetMapping("/filtrar")
    public String filtrarProductos(
            @RequestParam(required = false) Double precioMax,
            @RequestParam(required = false) Long categoriaId,
            Model model) {
        List<Producto> productos = productoService.filtrarProductos(precioMax, categoriaId);
        model.addAttribute("productos", productos);
        return "productos/lista";
    }

    // Buscar productos por nombre
    @GetMapping("/buscar")
    public String buscarProductos(@RequestParam String palabra, Model model) {
        List<Producto> productos = productoService.buscarPorNombre(palabra);
        model.addAttribute("productos", productos);
        return "productos/lista";
    }
}

