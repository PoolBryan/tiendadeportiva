package com.example.tiendadeportiva;

import com.example.tiendadeportiva.entity.Usuario;
import com.example.tiendadeportiva.repository.UsuarioRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.security.crypto.password.PasswordEncoder;

@SpringBootApplication
public class TiendadeportivaApplication {

    public static void main(String[] args) {
        SpringApplication.run(TiendadeportivaApplication.class, args);
    }

    @Bean
    CommandLineRunner run(UsuarioRepository usuarioRepository, PasswordEncoder passwordEncoder) {
        return args -> {
            if (usuarioRepository.findByUsername("admin").isEmpty()) {
                Usuario admin = new Usuario();
                admin.setUsername("admin");
                admin.setPassword(passwordEncoder.encode("admin123"));
                admin.setNombre("Administrador");
                admin.setEmail("admin@tienda.com");
                admin.setRol("ROLE_ADMIN");
                usuarioRepository.save(admin);
            }
        };
    }
}


