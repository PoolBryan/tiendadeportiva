package com.example.tiendadeportiva.entity;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "carrito_items")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class CarritoItem {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    // Producto asociado
    @ManyToOne
    @JoinColumn(name = "producto_id", nullable = false)
    private Producto producto;

    // Cantidad del producto en el carrito
    @Column(nullable = false)
    private Integer cantidad;

    // Opcional: relacionar con usuario (si implementas usuarios logueados)
    // @ManyToOne
    // @JoinColumn(name = "usuario_id")
    // private Usuario usuario;
}
