package com.example.tiendadeportiva.repository;

import com.example.tiendadeportiva.entity.DetalleVenta;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import java.util.List;

public interface DetalleVentaRepository extends JpaRepository<DetalleVenta, Long> {

    // Productos más vendidos: devuelve id de producto y cantidad total vendida, ordenados descendente
    @Query("SELECT dv.producto.id, SUM(dv.cantidad) FROM DetalleVenta dv GROUP BY dv.producto.id ORDER BY SUM(dv.cantidad) DESC")
    List<Object[]> findProductosMasVendidos();
}
