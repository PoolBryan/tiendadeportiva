package com.example.tiendadeportiva.service;

import com.example.tiendadeportiva.entity.Producto;
import com.example.tiendadeportiva.repository.ProductoRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ProductoService {

    private final ProductoRepository productoRepository;

    public ProductoService(ProductoRepository productoRepository) {
        this.productoRepository = productoRepository;
    }

    public List<Producto> listarProductosDisponibles() {
        return productoRepository.findByStockGreaterThan(0);
    }

    public List<Producto> listarPorCategoria(Long categoriaId) {
        return productoRepository.findByCategoriaIdAndStockGreaterThan(categoriaId, 0);
    }

    public List<Producto> buscarPorNombre(String palabra) {
        return productoRepository.findByNombreContainingIgnoreCaseAndStockGreaterThan(palabra, 0);
    }

    public List<Producto> filtrarProductos(Double precioMax, Long categoriaId) {
        if (precioMax != null && categoriaId != null) {
            return productoRepository.findByPrecioLessThanEqualAndCategoriaIdAndStockGreaterThan(precioMax, categoriaId, 0);
        } else if (precioMax != null) {
            return productoRepository.findByPrecioLessThanEqualAndStockGreaterThan(precioMax, 0);
        } else if (categoriaId != null) {
            return productoRepository.findByCategoriaIdAndStockGreaterThan(categoriaId, 0);
        } else {
            return productoRepository.findByStockGreaterThan(0);
        }
    }
}
