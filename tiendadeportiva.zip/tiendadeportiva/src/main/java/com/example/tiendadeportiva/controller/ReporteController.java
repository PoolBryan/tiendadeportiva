package com.example.tiendadeportiva.controller;

import com.example.tiendadeportiva.entity.Producto;
import com.example.tiendadeportiva.entity.Venta;
import com.example.tiendadeportiva.service.ReporteService;
import com.example.tiendadeportiva.service.ReporteService.ProductoCantidad;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.List;

@RestController
@RequestMapping("/api/reportes")
public class ReporteController {

    private final ReporteService reporteService;

    public ReporteController(ReporteService reporteService) {
        this.reporteService = reporteService;
    }

    @GetMapping("/ventas")
    public ResponseEntity<List<Venta>> ventasPorFecha(
            @RequestParam("inicio") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime inicio,
            @RequestParam("fin") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime fin) {
        return ResponseEntity.ok(reporteService.getVentasPorFecha(inicio, fin));
    }

    @GetMapping("/productos-mas-vendidos")
    public ResponseEntity<List<ProductoCantidad>> productosMasVendidos() {
        return ResponseEntity.ok(reporteService.getProductosMasVendidos());
    }

    @GetMapping("/stock-bajo")
    public ResponseEntity<List<Producto>> productosStockBajo(
            @RequestParam(defaultValue = "5") int limite) {
        return ResponseEntity.ok(reporteService.getProductosStockBajo(limite));
    }
}
