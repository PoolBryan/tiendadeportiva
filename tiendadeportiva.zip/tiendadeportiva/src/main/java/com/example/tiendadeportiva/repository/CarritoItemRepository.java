package com.example.tiendadeportiva.repository;

import com.example.tiendadeportiva.entity.CarritoItem;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CarritoItemRepository extends JpaRepository<CarritoItem, Long> {
}
