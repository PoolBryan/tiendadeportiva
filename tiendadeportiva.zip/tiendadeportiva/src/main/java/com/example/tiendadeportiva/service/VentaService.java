package com.example.tiendadeportiva.service;

import com.example.tiendadeportiva.entity.Venta;
import com.example.tiendadeportiva.repository.VentaRepository;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
public class VentaService {

    private final VentaRepository ventaRepository;

    public VentaService(VentaRepository ventaRepository) {
        this.ventaRepository = ventaRepository;
    }

    public Venta crearVenta(Venta venta) {
        venta.setFecha(LocalDateTime.now());
        venta.setEstado(Venta.EstadoVenta.PENDIENTE);
        return ventaRepository.save(venta);
    }

    public List<Venta> listarVentas() {
        return ventaRepository.findAll();
    }

    public List<Venta> listarVentasPorUsuario(Long usuarioId) {
        return ventaRepository.findByUsuarioId(usuarioId);
    }

    public List<Venta> listarVentasPorFecha(LocalDateTime inicio, LocalDateTime fin) {
        return ventaRepository.findByFechaBetween(inicio, fin);
    }

    public Optional<Venta> actualizarEstadoVenta(Long id, Venta.EstadoVenta nuevoEstado) {
        Optional<Venta> optVenta = ventaRepository.findById(id);
        if (optVenta.isPresent()) {
            Venta venta = optVenta.get();
            venta.setEstado(nuevoEstado);
            return Optional.of(ventaRepository.save(venta));
        }
        return Optional.empty();
    }
}
