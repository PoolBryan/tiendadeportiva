package com.example.tiendadeportiva.service;

import com.example.tiendadeportiva.entity.CarritoItem;
import com.example.tiendadeportiva.repository.CarritoItemRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class CarritoService {
    private final CarritoItemRepository carritoItemRepository;

    public CarritoService(CarritoItemRepository carritoItemRepository) {
        this.carritoItemRepository = carritoItemRepository;
    }

    public List<CarritoItem> obtenerTodos() {
        return carritoItemRepository.findAll();
    }

    public Optional<CarritoItem> obtenerPorId(Long id) {
        return carritoItemRepository.findById(id);
    }

    public CarritoItem agregarItem(CarritoItem item) {
        return carritoItemRepository.save(item);
    }

    public CarritoItem actualizarItem(CarritoItem item) {
        return carritoItemRepository.save(item);
    }

    public void eliminarItem(Long id) {
        carritoItemRepository.deleteById(id);
    }
}
