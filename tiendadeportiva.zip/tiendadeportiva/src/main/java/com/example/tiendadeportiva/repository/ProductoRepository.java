package com.example.tiendadeportiva.repository;

import com.example.tiendadeportiva.entity.Producto;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface ProductoRepository extends JpaRepository<Producto, Long> {

    List<Producto> findByStockGreaterThan(int cantidad);

    List<Producto> findByCategoriaIdAndStockGreaterThan(Long categoriaId, int cantidad);

    List<Producto> findByNombreContainingIgnoreCaseAndStockGreaterThan(String palabra, int cantidad);

    List<Producto> findByPrecioLessThanEqualAndCategoriaIdAndStockGreaterThan(Double precio, Long categoriaId, int cantidad);

    List<Producto> findByPrecioLessThanEqualAndStockGreaterThan(Double precio, int cantidad);

    // NUEVO: Productos con stock menor o igual a un límite (para reporte stock bajo)
    @Query("SELECT p FROM Producto p WHERE p.stock <= :limite")
    List<Producto> findProductosStockBajo(int limite);
}

