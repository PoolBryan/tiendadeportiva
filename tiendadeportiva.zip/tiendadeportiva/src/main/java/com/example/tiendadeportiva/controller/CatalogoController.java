package com.example.tiendadeportiva.controller;

import com.example.tiendadeportiva.entity.Producto;
import com.example.tiendadeportiva.service.ProductoService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/catalogo")
public class CatalogoController {

    private final ProductoService productoService;

    public CatalogoController(ProductoService productoService) {
        this.productoService = productoService;
    }

    // Listar productos con stock > 0
    @GetMapping("/productos")
    public List<Producto> listarProductosDisponibles() {
        return productoService.listarProductosDisponibles();
    }

    // Listar productos por categoría (stock > 0)
    @GetMapping("/categoria/{categoriaId}")
    public List<Producto> listarPorCategoria(@PathVariable Long categoriaId) {
        return productoService.listarPorCategoria(categoriaId);
    }

    // Buscar productos por nombre o palabra clave (stock > 0)
    @GetMapping("/buscar")
    public List<Producto> buscarPorNombre(@RequestParam String palabra) {
        return productoService.buscarPorNombre(palabra);
    }

    // Filtrar productos por precio máximo y/o categoría (stock > 0)
    @GetMapping("/filtrar")
    public List<Producto> filtrarProductos(
            @RequestParam(required = false) Double precioMax,
            @RequestParam(required = false) Long categoriaId) {
        return productoService.filtrarProductos(precioMax, categoriaId);
    }
}
