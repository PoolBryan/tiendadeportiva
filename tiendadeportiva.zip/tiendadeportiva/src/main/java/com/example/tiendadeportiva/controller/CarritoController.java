package com.example.tiendadeportiva.controller;

import com.example.tiendadeportiva.entity.CarritoItem;
import com.example.tiendadeportiva.service.CarritoService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/carrito")
public class CarritoController {
    private final CarritoService carritoService;

    public CarritoController(CarritoService carritoService) {
        this.carritoService = carritoService;
    }

    @GetMapping
    public List<CarritoItem> listarItems() {
        return carritoService.obtenerTodos();
    }

    @PostMapping
    public CarritoItem agregarItem(@RequestBody CarritoItem item) {
        return carritoService.agregarItem(item);
    }

    @PutMapping("/{id}")
    public ResponseEntity<CarritoItem> actualizarItem(@PathVariable Long id, @RequestBody CarritoItem item) {
        return carritoService.obtenerPorId(id)
                .map(existente -> {
                    existente.setCantidad(item.getCantidad());
                    existente.setProducto(item.getProducto());
                    return ResponseEntity.ok(carritoService.actualizarItem(existente));
                })
                .orElse(ResponseEntity.notFound().build());
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminarItem(@PathVariable Long id) {
        carritoService.eliminarItem(id);
        return ResponseEntity.noContent().build();
    }
}
