package com.example.tiendadeportiva.repository;

import com.example.tiendadeportiva.entity.Venta;
import org.springframework.data.jpa.repository.JpaRepository;

import java.time.LocalDateTime;
import java.util.List;

public interface VentaRepository extends JpaRepository<Venta, Long> {

    // Ventas entre fechas (para reporte de ventas por fecha)
    List<Venta> findByFechaBetween(LocalDateTime start, LocalDateTime end);

    // Ventas por usuario (si necesitas)
    List<Venta> findByUsuarioId(Long usuarioId);
}

