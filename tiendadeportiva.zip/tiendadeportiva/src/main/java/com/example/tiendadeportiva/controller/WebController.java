package com.example.tiendadeportiva.controller;

import com.example.tiendadeportiva.entity.Categoria;
import com.example.tiendadeportiva.entity.Producto;
import com.example.tiendadeportiva.service.CategoriaService;
import com.example.tiendadeportiva.service.ProductoService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.List;

@Controller
public class WebController {

    private final CategoriaService categoriaService;
    private final ProductoService productoService;

    public WebController(CategoriaService categoriaService, ProductoService productoService) {
        this.categoriaService = categoriaService;
        this.productoService = productoService;
    }

    @GetMapping("/")
    public String home(Model model) {
        List<Categoria> categorias = categoriaService.getAll();
        List<Producto> productos = productoService.getAll();

        model.addAttribute("categorias", categorias);
        model.addAttribute("productos", productos);

        return "index"; // nombre de la plantilla Thymeleaf index.html
    }
}
