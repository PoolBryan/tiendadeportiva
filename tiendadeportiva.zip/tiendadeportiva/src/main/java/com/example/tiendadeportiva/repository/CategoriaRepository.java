package com.example.tiendadeportiva.repository;

import com.example.tiendadeportiva.entity.Categoria;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CategoriaRepository extends JpaRepository<Categoria, Long> {
}
