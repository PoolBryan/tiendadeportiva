package com.example.tiendadeportiva;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TiendadeportivaApplicationTests {

	@Test
	void contextLoads() {
	}

}
